enum TaskState {
  running,
  paused,
  success,
  canceled,
  error
}


